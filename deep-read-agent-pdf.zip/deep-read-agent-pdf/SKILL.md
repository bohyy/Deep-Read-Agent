---
name: deep-read-agent-pdf
description: Multi-source paper finder + PDF full-text extractor for deep reading. Searches arXiv (and optional HF signal), ranks by recency+impact, downloads arXiv PDFs, extracts full text into chunks for Claude to write 4-section deep-read notes, then writes results to Notion with a single '推荐指数' field. Notion credentials are provided at runtime (not stored).
---

# Deep Read Agent (PDF)

## What it does
1) Ask for config (time range & deep-read count) if needed  
2) Search recent papers for a topic (default: arXiv; optional HF supplement)  
3) Rank candidates using recency + (optional) Semantic Scholar citationCount as an impact signal  
4) For the top N papers, download arXiv PDF and extract full text into chunks  
5) Claude uses the chunks to generate 4 sections:
- 精读论文总结
- 实验方法和过程
- 结论创新点
- 如果我写可以如何优化
and a single 推荐指数 (🔥/👍/👀/❌)  
6) Save everything to Notion (deduplicated by 论文链接)

## Exposed functions
- ask_config(): returns the questions to ask user
- discover_and_extract(input): returns top N papers + PDF text chunks
- save_to_notion(input): writes the deep-read result to Notion (runtime credentials)

## Notion database properties required (exact names)
- Title (title)
- 论文链接 (url)
- 推荐指数 (select: 🔥 强烈推荐 / 👍 推荐 / 👀 可关注 / ❌ 略过)
- 精读论文总结 (rich_text)
- 实验方法和过程 (rich_text)
- 结论创新点 (rich_text)
- 如果我写可以如何优化 (rich_text)

## Runtime credentials (tool input)
- notion_api_key
- notion_database_id

No secrets are stored in environment variables by this skill.
