
import fetch from "node-fetch";
import pdf from "pdf-parse";
import { z } from "zod";

const AskConfigOutput = {
  questions: [
    "时间范围要多久？（例如：7天 / 30天 / 90天 / 180天）",
    "需要深读多少篇？（建议 1-5）",
    "研究方向关键词是什么？（例如：LLM inference efficiency / multimodal generation / diffusion acceleration）"
  ],
  defaults: { time_range_days: 30, deep_read_count: 2 }
};

export async function ask_config() {
  return AskConfigOutput;
}

const DiscoverSchema = z.object({
  topic: z.string().min(1),
  time_range_days: z.number().min(1).max(3650).default(180),
  deep_read_count: z.number().min(1).max(5).default(4),
  max_candidates: z.number().min(10).max(200).optional().default(80),
  include_hf: z.boolean().optional().default(true),
  use_semantic_scholar: z.boolean().optional().default(true)
});

function stripXml(s) {
  return s.replace(/<!\[CDATA\[|\]\]>/g, "").trim();
}

function extractArxivIdFromEntryId(entryId) {
  const m = entryId.match(/arxiv\.org\/abs\/(\d+\.\d+)(v\d+)?/i);
  return m ? m[1] : null;
}

function withinDays(isoDate, days) {
  const t = Date.parse(isoDate);
  if (Number.isNaN(t)) return true;
  const diffDays = (Date.now() - t) / (1000 * 60 * 60 * 24);
  return diffDays <= days;
}

async function searchArxiv(topic, maxResults = 80) {
  const q = encodeURIComponent(topic);
  const url = `http://export.arxiv.org/api/query?search_query=all:${q}&sortBy=submittedDate&sortOrder=descending&max_results=${maxResults}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`arXiv API failed: ${res.status}`);
  const xml = await res.text();

  const entries = [...xml.matchAll(/<entry>([\s\S]*?)<\/entry>/g)].map(m => m[1]);
  const papers = [];

  for (const e of entries) {
    const title = stripXml((e.match(/<title>([\s\S]*?)<\/title>/) || [,""])[1]).replace(/\s+/g, " ");
    const summary = stripXml((e.match(/<summary>([\s\S]*?)<\/summary>/) || [,""])[1]).replace(/\s+/g, " ");
    const idUrl = stripXml((e.match(/<id>([\s\S]*?)<\/id>/) || [,""])[1]);
    const published = stripXml((e.match(/<published>([\s\S]*?)<\/published>/) || [,""])[1]);
    const updated = stripXml((e.match(/<updated>([\s\S]*?)<\/updated>/) || [,""])[1]);
    const arxivId = extractArxivIdFromEntryId(idUrl);
    if (!arxivId) continue;

    papers.push({
      source: "arXiv",
      arxiv_id: arxivId,
      title,
      abstract: summary,
      published: published || updated || null,
      link_abs: `https://arxiv.org/abs/${arxivId}`,
      link_pdf: `https://arxiv.org/pdf/${arxivId}.pdf`
    });
  }
  return papers;
}

async function fetchHFPapersPage() {
  const res = await fetch("https://huggingface.co/papers");
  if (!res.ok) return "";
  return await res.text();
}

async function searchHF(topic) {
  const html = await fetchHFPapersPage();
  if (!html) return [];
  const terms = topic.toLowerCase().split(/\s+/).filter(Boolean).slice(0, 6);

  const matches = [...html.matchAll(/href="(\/papers\/[^"]+)".*?>(.*?)<\/a>/g)];
  const items = matches
    .map(m => ({
      source: "HF",
      title: m[2].replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim(),
      link: "https://huggingface.co" + m[1]
    }))
    .filter(it => {
      const t = it.title.toLowerCase();
      return terms.some(x => t.includes(x));
    });

  const seen = new Set();
  const out = [];
  for (const it of items) {
    const k = it.title.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(it);
  }
  return out.slice(0, 30);
}

async function semanticScholarImpact(arxivId) {
  const url = `https://api.semanticscholar.org/graph/v1/paper/arXiv:${arxivId}?fields=citationCount,year`;
  const res = await fetch(url);
  if (!res.ok) return { citationCount: null, year: null };
  const data = await res.json();
  return { citationCount: data.citationCount ?? null, year: data.year ?? null };
}

function scorePaper(p, topic) {
  let s = 0;
  const t = p.title.toLowerCase();
  const terms = topic.toLowerCase().split(/\s+/).filter(Boolean);

  for (const term of terms.slice(0, 8)) {
    if (term.length < 3) continue;
    if (t.includes(term)) s += 3;
    if ((p.abstract || "").toLowerCase().includes(term)) s += 1;
  }

  if (p.published) {
    const days = (Date.now() - Date.parse(p.published)) / (1000 * 60 * 60 * 24);
    if (!Number.isNaN(days)) s += Math.max(0, 30 - Math.min(30, days));
  }

  if (typeof p.citationCount === "number") {
    s += Math.min(25, Math.log10(p.citationCount + 1) * 10);
  }

  return s;
}

function chunkText(text, maxChars = 12000) {
  const clean = text.replace(/\r/g, "\n").replace(/\n{3,}/g, "\n\n");
  const chunks = [];
  let i = 0;
  while (i < clean.length) {
    chunks.push(clean.slice(i, i + maxChars));
    i += maxChars;
  }
  return chunks.slice(0, 10);
}

async function downloadAndExtractPdf(pdfUrl) {
  const res = await fetch(pdfUrl);
  if (!res.ok) throw new Error(`PDF download failed: ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  const parsed = await pdf(buf);
  return parsed.text || "";
}

export async function discover_and_extract(input) {
  const cfg = DiscoverSchema.parse(input);

  const arxiv = await searchArxiv(cfg.topic, cfg.max_candidates);
  const arxivFiltered = arxiv.filter(p => !p.published || withinDays(p.published, cfg.time_range_days));

  const hf = cfg.include_hf ? await searchHF(cfg.topic) : [];

  const enriched = [];
  for (const p of arxivFiltered) {
    if (cfg.use_semantic_scholar) {
      const imp = await semanticScholarImpact(p.arxiv_id);
      enriched.push({ ...p, ...imp });
    } else {
      enriched.push(p);
    }
  }

  const ranked = enriched
    .map(p => ({ ...p, _score: scorePaper(p, cfg.topic) }))
    .sort((a, b) => b._score - a._score);

  const selected = ranked.slice(0, cfg.deep_read_count);

  const outputs = [];
  for (const p of selected) {
    let chunks = [];
    let pdf_error = null;

    try {
      const fulltext = await downloadAndExtractPdf(p.link_pdf);
      chunks = chunkText(fulltext);
    } catch (e) {
      pdf_error = String(e?.message || e);
      chunks = [p.abstract || ""];
    }

    outputs.push({
      title: p.title,
      arxiv_id: p.arxiv_id,
      link: p.link_abs,
      pdf: p.link_pdf,
      abstract: p.abstract,
      impact: { citationCount: p.citationCount ?? null, year: p.year ?? null },
      extracted: { chunks, pdf_error },
      hints: {
        scholar_search_url: `https://scholar.google.com/scholar?q=${encodeURIComponent(p.title)}`,
        hf_matches_sample: hf.slice(0, 10)
      }
    });
  }

  return {
    ok: true,
    topic: cfg.topic,
    time_range_days: cfg.time_range_days,
    deep_read_count: cfg.deep_read_count,
    papers: outputs,
    instructions_for_claude:
      "For EACH paper, read the extracted chunks and produce: 推荐指数(🔥 强烈推荐/👍 推荐/👀 可关注/❌ 略过), 精读论文总结, 实验方法和过程, 结论创新点, 如果我写可以如何优化. Then call save_to_notion with items[]."
  };
}

const SaveSchema = z.object({
  notion_api_key: z.string().min(1),
  notion_database_id: z.string().min(1),
  items: z.array(z.object({
    title: z.string().min(1),
    paper_link: z.string().url(),
    recommend_index: z.enum(["🔥 强烈推荐", "👍 推荐", "👀 可关注", "❌ 略过"]),
    summary: z.string().min(1),
    experiments: z.string().min(1),
    innovation: z.string().min(1),
    optimization: z.string().min(1)
  })).min(1)
});

async function notionQueryByLink(apiKey, dbId, link) {
  const res = await fetch(`https://api.notion.com/v1/databases/${dbId}/query`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Notion-Version": "2022-06-28",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      filter: { property: "论文链接", url: { equals: link } }
    })
  });
  const data = await res.json();
  return Array.isArray(data.results) && data.results.length > 0;
}

async function notionInsert(apiKey, dbId, item) {
  const res = await fetch("https://api.notion.com/v1/pages", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Notion-Version": "2022-06-28",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      parent: { database_id: dbId },
      properties: {
        Title: { title: [{ text: { content: item.title } }] },
        "论文链接": { url: item.paper_link },
        "推荐指数": { select: { name: item.recommend_index } },
        "精读论文总结": { rich_text: [{ text: { content: item.summary.slice(0, 1900) } }] },
        "实验方法和过程": { rich_text: [{ text: { content: item.experiments.slice(0, 1900) } }] },
        "结论创新点": { rich_text: [{ text: { content: item.innovation.slice(0, 1900) } }] },
        "如果我写可以如何优化": { rich_text: [{ text: { content: item.optimization.slice(0, 1900) } }] }
      }
    })
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Notion insert failed: ${res.status} ${err}`);
  }
  return true;
}

export async function save_to_notion(input) {
  const { notion_api_key, notion_database_id, items } = SaveSchema.parse(input);

  const results = [];
  for (const it of items) {
    const exists = await notionQueryByLink(notion_api_key, notion_database_id, it.paper_link);
    if (exists) {
      results.push({ title: it.title, link: it.paper_link, skipped: true, reason: "duplicate" });
      continue;
    }
    await notionInsert(notion_api_key, notion_database_id, it);
    results.push({ title: it.title, link: it.paper_link, skipped: false });
  }

  return { ok: true, results };
}
